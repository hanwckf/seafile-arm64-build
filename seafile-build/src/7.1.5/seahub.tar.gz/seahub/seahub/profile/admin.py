# Copyright (c) 2012-2016 Seafile Ltd.
from django.contrib import admin
#from profile.models import UserProfile

#admin.site.register(UserProfile)
