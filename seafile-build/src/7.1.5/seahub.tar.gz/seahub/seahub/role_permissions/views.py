# Copyright (c) 2012-2016 Seafile Ltd.
from django.shortcuts import render

# Create your views here.
