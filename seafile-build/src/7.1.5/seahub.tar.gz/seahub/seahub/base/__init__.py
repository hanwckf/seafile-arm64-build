# Copyright (c) 2012-2016 Seafile Ltd.
default_app_config = 'seahub.base.apps.BaseConfig'
