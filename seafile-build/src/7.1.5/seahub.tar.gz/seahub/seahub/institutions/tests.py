# Copyright (c) 2012-2016 Seafile Ltd.
from django.test import TestCase

# Create your tests here.
