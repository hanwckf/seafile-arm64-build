# Copyright (c) 2012-2016 Seafile Ltd.
from django.contrib import admin
from seahub.avatar.models import Avatar

admin.site.register(Avatar)
