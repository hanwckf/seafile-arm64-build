# Copyright (c) 2012-2016 Seafile Ltd.
VERSION = '0.3.3'

from .handlers import update_session_auth_hash
