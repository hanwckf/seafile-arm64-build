"""
Define RPC functions needed to generate
"""

# [ <ret-type>, [<arg_types>] ]
func_table = [
    [ "int", ["string"] ],
    [ "objlist", ["int", "int", "string"] ]
]
