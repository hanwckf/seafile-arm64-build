from ccnet.rpc import CcnetThreadedRpcClient
