#ifndef UPLOAD_FILE_H
#define UPLOAD_FILE_H

int
upload_file_init (evhtp_t *evhtp, const char *http_temp_dir);

#endif
