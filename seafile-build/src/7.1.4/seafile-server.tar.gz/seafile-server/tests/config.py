USER = 'testuser@test.seafile.com'
PASSWORD = 'testuser'
USER2 = 'testuser2@test.seafile.com'
PASSWORD2 = 'testuser2'
ADMIN_USER = 'adminuser@test.seafile.com'
ADMIN_PASSWORD = 'adminuser'

INACTIVE_USER = 'inactiveuser@test.seafile.com'
INACTIVE_PASSWORD = 'inactiveuser'
