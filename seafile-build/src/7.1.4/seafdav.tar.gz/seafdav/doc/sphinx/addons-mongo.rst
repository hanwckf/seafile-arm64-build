MongoDB WebDAV provider
=======================

Module description
------------------
.. automodule::  wsgidav.samples.mongo_dav_provider
