Sample WSGI Server
==================

.. literalinclude:: ../../wsgidav/server/server_sample.py
   :linenos:
   :language: python
