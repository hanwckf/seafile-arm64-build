MongoDB property manager
========================

.. note:: This is **not** production code.

Module description
------------------
.. automodule::  wsgidav.prop_man.mongo_property_manager
