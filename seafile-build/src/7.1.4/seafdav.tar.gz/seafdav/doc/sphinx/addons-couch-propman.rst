CouchDB property manager
========================

.. note:: This is **not** production code.


Module Description
------------------
.. automodule::  wsgidav.prop_man.couch_property_manager
